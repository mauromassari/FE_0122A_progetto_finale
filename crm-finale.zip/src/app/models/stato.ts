export interface Stato {
  id: number,
  nome: string
}
